import pandas as pd

df = pd.read_csv("out_onlytrain_sorted.csv",header=None)
l = list(df[2].unique())
print(l)
exit()
for i in l:
    df1 = df[df[2]==i]
    df1.to_csv(i+".csv",header=None,index=None)
